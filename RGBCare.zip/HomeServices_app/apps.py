from django.apps import AppConfig


class HomeservicesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'HomeServices_app'
